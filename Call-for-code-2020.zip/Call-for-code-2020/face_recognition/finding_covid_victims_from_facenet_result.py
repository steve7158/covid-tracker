import pandas as pd
import os

def find_subject(subject):
    facenet_result = pd.read_csv('facenet/facenet_classification.csv')
    subject_found = facenet_result.loc[facenet_result.iloc[:,1].values == subject]
    print(subject_found.head())
    subject_found.to_csv('{}_information.csv'.format(subject))
