from body_detection.pedestrian_detection import mask_rcnn
from proximity_detection import proximity_analyzer
import cv2
import os
import numpy as np

import matplotlib.pyplot as plt

img = cv2.imread('test_images/test3.jpg')
img_2 = cv2.imread('test_images/test3.jpg')

_,image_mask,bbox = mask_rcnn.detect_people(img)
group_bbox, new_bbox = proximity_analyzer.detector(bbox)

for i in range(len(new_bbox)):
    x1,y1,x2,y2 = new_bbox[i]
    cv2.rectangle(img, (y1,x1), (y2,x2),10,2)


plt.imshow(img)
plt.show()
for i in range(len(bbox)):
    x1,y1,x2,y2 = bbox[i]
    cv2.rectangle(img_2, (y1,x1), (y2,x2),10,2)


plt.imshow(img_2)
plt.show()
