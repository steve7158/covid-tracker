#!/usr/bin/env python3.6
import cv2
import os
import numpy as np
import pandas as pd
from body_detection.pedestrian_detection import mask_rcnn
from proximity_detection import proximity_analyzer
from face_recognition.facenet import facenet
from face_recognition.head_detection import head_detection
from termcolor import colored
from flask import Flask
from flask import render_template, request
from flask import flash
from flask import redirect
from flask import url_for
from flask import send_file
from flask import session
from flask import logging
from wtforms import Form
from wtforms import StringField
from wtforms import TextAreaField
from wtforms import DateTimeField
from wtforms.fields.html5 import DateField
from wtforms import TextAreaField
from wtforms import IntegerField
from wtforms import BooleanField
from wtforms import FileField
from wtforms import validators
from passlib.hash import sha256_crypt
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.sql import func
import math
from pytz import timezone
from datetime import datetime
from werkzeug.utils import secure_filename
app = Flask(__name__)

UPLOAD_FOLDER = 'static/files/'
victim_name=''
def make_head_dataset(video_path):
    if os.path.isfile(video_path):
        video_cap = cv2.VideoCapture(video_path)
        # frameRate = cap.get(5)
        i=0
        count = 0
        total=int(video_cap.get(cv2.CAP_PROP_FRAME_COUNT))
        print(total)
        index=0
        for i in range(total):
            ret, frame=video_cap.read()
            video_path_split=video_path.split('/')
            filename = '-'.join(video_path_split)
            head_detection.head_detection(frame, filename)
        video_cap.release()
        # cv2.destroyAllWindows()
        return True
    else:
        return False

def facenet_facerecognition():
    path_to_dataset = os.path.abspath('face_recognition/head_detection/head_data/')
    if len(os.listdir(path_to_dataset))>0:
        facenet.main(path_to_dataset)
        return True
    else:
        return False

def find_subject(subject):
    csv_file = os.path.abspath('face_recognition/facenet/facenet_classification.csv')
    facenet_result = pd.read_csv(csv_file)
    subject_found = facenet_result.loc[facenet_result.iloc[:,1].values == subject]
    if subject_found:
        subject_found.to_csv('victim_search/{}_information.csv'.format(subject))
        return True
    else:
        return False
############################Under Development########################################
"""
def contact_search(frame, victim):
    _,image_mask,bbox = mask_rcnn.detect_people(frame)
    group_bbox, new_bbox = proximity_analyzer.detector(bbox)
    for indi_group in group_bbox:
        for box in indi_group:
            img_copy = np.copy(frame)
            cropped_image = img_copy[y1:y2,x1:x2]
            head_bbox = head_detection.return_detected_head(cropped_image)
        for head in head_bbox:
            xh1,yh1,xh2,yh2 = head
            img_copy_2 = np.copy(frame)
            head_crop = img_copy_2[yh1:yh2, xh1:xh2]
            indi_face = facenet.main(head_crop)
"""
##################################################################################


def main_control(from_date, to_date, victim_name):
    videofile_dir = 'video_data/'
    from_date_split = from_date.split('-')
    print(from_date_split)
    to_date_split = to_date.split('-')
    print(to_date_split)
    videos_dir_for_consideration=[]
    #gather data over a range
    # try:
    for year in range(int(from_date_split[0]), int(to_date_split[0])+1):
        for month in range(int(from_date_split[1]), int(to_date_split[1])+1):
            #31 days month
            if int(month) in [1,3,5,7,8,10,12]:
                print('the time is in 31 day period')
                if int(month) == int(from_date_split[2]):
                    for day in range(int(from_date_split[2]), 32):
                        video_dir = os.path.join(videofile_dir, str(year), str(month), str(day)+'')
                        if os.path.isdir(video_dir):
                            videos_dir_for_consideration.append(video_dir)
                else:
                    for day in range(1,32):
                        video_dir = os.path.join(videofile_dir, str(year), str(month), str(day)+'')
                        if os.path.isdir(video_dir):
                            videos_dir_for_consideration.append(video_dir)
            #30 days months
            elif int(month) in [4,6,9,11]:
                print('the time is in 30 day period')
                if int(month) == int(from_date_split[2]):
                    for day in range(int(from_date_split[2]), 31):
                        video_dir = os.path.join(videofile_dir, str(year), str(month), str(day)+'')
                        if os.path.isdir(video_dir):
                            videos_dir_for_consideration.append(video_dir)
                else:
                    for day in range(1, 31):
                        video_dir = os.path.join(videofile_dir, str(year), str(month), str(day)+'')
                        if os.path.isdir(video_dir):
                            videos_dir_for_consideration.append(video_dir)
            #for february
            elif int(month) == 2:
                print('the time is in 28 day period')
                if int(month) == int(from_date_split[2]):
                    for day in range(int(from_date_split[2]), 29):
                        video_dir = os.path.join(videofile_dir, str(year), str(month), str(day)+'')
                        if os.path.isdir(video_dir):
                            videos_dir_for_consideration.append(video_dir)
                else:
                    for day in range(1,29):
                        video_dir = os.path.join(videofile_dir, str(year), str(month), str(day)+'')
                        if os.path.isdir(video_dir):
                            videos_dir_for_consideration.append(video_dir)
    print(videos_dir_for_consideration)
    for i in range(len(videos_dir_for_consideration)):
        day_dir = videos_dir_for_consideration[i]
        for video in os.listdir(day_dir):
            video_path = os.path.join(day_dir,video)
            print(colored(video_path,'green', 'on_red'))
            if make_head_dataset(video_path):
                print('head data made')
                if facenet_facerecognition():
                    print('face recognition for all heads in the frame done!')
                    if find_subject(victim_name):
                        print('operation successfull')
                    else:
                        print("subject not found")
                        return False
                else:
                    print("face recognition failed")
                    return False
            else:
                print('operation failed')
                return False
    return True
    # except Exception as e:
    #     print(e)
    #     return False


def control_data_structure(image_path, victim_name, accuracy):
    result = []
    for i in range(len(image_path)):
        temp_list= [image_path[i], victim_name[i], accuracy[i]]
        result.append(temp_list)
    return result


@app.route('/',methods=['GET','POST'])
def index():
    if request.method == 'POST':
        from_date=request.form['from_date']
        to_date=request.form['to_date']
        global victim_name
        victim_name=request.form['victim_name']
        victim_name = victim_name.lower()
        print(from_date, type(from_date), victim_name, type(victim_name))
        mc = main_control(from_date, to_date, victim_name)
        print(colored(mc, 'green', 'on_red'))
        if mc:
            return redirect(url_for('result'))
        else:
            msg = "Subject not found"
            return render_template('home.html',error = msg)
    return render_template('home.html')

@app.route('/result')
def result():
    global victim_name
    if os.path.isfile('victim_search/{}_information.csv'.format(victim_name)):
        dataframe=pd.read_csv('victim_search/{}_information.csv'.format(victim_name))
        image_path = list(dataframe.iloc[:,0].values)
        victim_name = list(dataframe.iloc[:,1].values)
        accuracy = list(dataframe.iloc[:,2].values)
        results=control_data_structure(image_path, victim_name, accuracy)
        return render_template('result.html', results=results)

    else:
        results = []
        return render_template('result.html', results=results)
if __name__ =='__main__':

    app.secret_key='secret123'
    app.run(debug=True, port = 8000)
