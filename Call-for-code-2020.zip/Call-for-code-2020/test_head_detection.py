import numpy as np
import time
import imageio
import os
import cv2
from face_recognition.head_detection import head_detection

for im_dir in os.listdir('test_images/facenet/'):
    im_names = os.listdir('test_images/facenet/{}/'.format(im_dir))
    for im_name in im_names:
        print('test_images/facenet/{}/{}'.format(im_dir, im_name))
        img =  imageio.imread('test_images/facenet/{}/{}'.format(im_dir, im_name))
        # h,w=img.shape
        # img = np.reshape(img, (h,w,1))
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
        filepath = 'test_images/facenet/{}/{}'.format(im_dir, im_name)
        filename = os.path.splitext(os.path.basename(filepath))[0]
        head_detection.head_detection(img, filename)
"""
im_names = os.listdir('test_images/head_detection_test/')
for im_name in im_names:
    print('test_images/head_detection_test/{}'.format(im_name))
    # img =  imageio.imread('test_images/head_detection_test/{}'.format(im_name))
    img = cv2.imread('test_images/head_detection_test/{}'.format(im_name), cv2.IMREAD_COLOR)
    # h,w=img.shape
    # img = np.reshape(img, (h,w,1))
    # img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    # img=cv2.resize(img, (400,400))
    filename=os.path.splitext(im_name)[0]
    head_detection.head_detection(img, filename)
    time.sleep(8)
print('Done!')
"""
