import cv2
import mask_rcnn
import matplotlib.pyplot as plt

im=cv2.imread('data_to_test/test1.jpg')

image = mask_rcnn.detect_people(im)

print(image)

fig, axs = plt.subplots(1,2,figsize=(5,5))
axs[0].imshow(image[0])
axs[1].imshow(image[1])
plt.show()
