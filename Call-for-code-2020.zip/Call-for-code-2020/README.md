# Call-for-code-2020
## Algorithm goes like this: 

1. Cctv cameras run continuously as they should recording videos into a storage. 

2. Then we will take the facial of people in quarantine.. Then via prediction of how manny days the person could have been infected from the virus.. We extract the footage from within that timeline and then search our infected individuals face in those frames. 


3. Then within those perticular frames of videos we will run our proximity detection algorithm to check with whoom that individual is in contact wether or not that person sneezed or coughed publically. 


4. From this information we will make a tree graph branching from our individual to the next individual and so on they will also be tracked. 


5. After building the complete we will finally extract the names of the infected people using face recognition we will use these names to carry out tests on those targeted individual perticularly 


6. If you r still wondering how we will track the spread of virus.... We will keep the location of the cctv and using this we track the spread.

## Geting started

1. Fork this repository *Important* do not clone this particular repository directlly.

2. Clone your forked repository.

3. Make if you want to work on new sub task.

4. Push the code after completing the task.

