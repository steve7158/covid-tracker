import os
import cv2
from face_recognition.facenet import facenet

path_to_dataset = os.path.abspath('test_images/facenet/')
facenet.main(path_to_dataset)

