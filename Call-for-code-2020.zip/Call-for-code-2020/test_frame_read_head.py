from tqdm import tqdm
import cv2
import os
import numpy as np
import pandas as pd
from body_detection.pedestrian_detection import mask_rcnn
from proximity_detection import proximity_analyzer
from face_recognition.facenet import facenet
from face_recognition.head_detection import head_detection
import imageio
from termcolor import colored
import math
from pytz import timezone
from datetime import datetime
from werkzeug.utils import secure_filename


# def make_head_dataset(video_path):
#     if os.path.isfile(video_path):
#         video_cap = cv2.VideoCapture(video_path)
#         # frameRate = cap.get(5)
#         i=0
#         count = 0
#         total=int(video_cap.get(cv2.CAP_PROP_FRAME_COUNT))
#         print(total)
#         index=0
#         for i in range(total):
#             print(i)
#             ret, frame=video_cap.read()
#             video_path_split=video_path.split('/')
#             filename = '-'.join(video_path_split)
#             frame = cv2.resize(frame, (400,400))
#             try:
#                 status=head_detection.head_detection(frame, filename)
#             except Exception as e:
#                 print(e)
        # video_cap.release()
        # cv2.destroyAllWindows()
    #     return True
    # else:
    #     return False

video_path='/media/steve/054DA50B580BD049/steve/projects/hackathon/call-for-code-2020/Call-for-code-2020/video_data/2020/5/3/GIRL_ON_SHOULDERS.mov'
if os.path.isfile(video_path):
    video_cap = cv2.VideoCapture(video_path)
    # frameRate = cap.get(5)
    i=0
    count = 0
    total=int(video_cap.get(cv2.CAP_PROP_FRAME_COUNT))
    print(total)
    index=0
    for i in tqdm(range(total)):
        # print(i)
        ret, frame=video_cap.read()
        video_path_split=video_path.split('/')
        filename = '-'.join(video_path_split)
        frame = cv2.resize(frame, (100,100))

        # try:
        #     # status=head_detection.head_detection(frame, filename)
        # except Exception as e:
        #     print(e)

        #atempt 2 first storing the diffrent frames in the video in a directory and then performing detection on the stored data

        cv2.imwrite('temp_frame_storage/{}.png'.format(i), frame)

im_names = os.listdir('temp_frame_storage/')
for im_name in im_names:
    img =  cv2.imread('temp_frame_storage/{}'.format(im_name))
    # h,w=img.shape
    # img = np.reshape(img, (h,w,1))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    print('temp_frame_storage/{} --- '.format(im_name), img.shape)
    # filepath = 'temp_frame_storage/{}'.format(im_name)
    filename = os.path.splitext(im_name)[0]
    # head_detection.head_detection(img, filename)

# status = make_head_dataset('/media/steve/054DA50B580BD049/steve/projects/hackathon/call-for-code-2020/Call-for-code-2020/video_data/2020/5/3/GIRL_ON_SHOULDERS.mov')
