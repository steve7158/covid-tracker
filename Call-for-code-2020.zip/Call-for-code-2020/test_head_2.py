
from tqdm import tqdm
import cv2
import os
import numpy as np
import pandas as pd
from body_detection.pedestrian_detection import mask_rcnn
from proximity_detection import proximity_analyzer
from face_recognition.facenet import facenet
from face_recognition.head_detection import head_detection
import imageio
from termcolor import colored
import math
from pytz import timezone
from datetime import datetime
from werkzeug.utils import secure_filename




im_names = os.listdir('temp_frame_storage/')
for im_name in im_names:
    img =  cv2.imread('temp_frame_storage/{}'.format(im_name))
    # h,w=img.shape
    # img = np.reshape(img, (h,w,1))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    print('temp_frame_storage/{} --- '.format(im_name), img.shape)
    # filepath = 'temp_frame_storage/{}'.format(im_name)
    filename = os.path.splitext(im_name)[0]
    head_detection.head_detection(img, filename)
