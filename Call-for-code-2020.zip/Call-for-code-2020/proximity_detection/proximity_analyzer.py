ROOT_DIR = '../'
import cv2
import os
import sys
import numpy as np

#IMPORT MASK RCNN
sys.path.append(os.path.join(ROOT_DIR, "body_detection/pedestrian_detection/"))
import mask_rcnn
def line_intersection(p1, p2):
    result = False
    x1,y1,x2,y2=p1
    xj1,yj1,xj2,yj2=p2
    if ((xj1>min(x1,x2) and xj1<max(x1,x2)) or (xj2>min(x1,x2) and xj2<max(x1,x2))) and ((yj1>min(y1,y2) and yj1<max(y1,y2)) or (yj2>min(y1,y2) and yj2< max(y1,y2))):
        result = True
        # print('intersects')
    return result

# def union(a,b):
#     x = min(a[0], b[0])
#     y = min(a[1], b[1])
#     w = max(a[0]+a[2], b[0]+b[2]) - x
#     h = max(a[1]+a[3], b[1]+b[3]) - y
#     return (x, y, w, h)
#
# def intersection(a,b):
#     x = max(a[0], b[0])
#     y = max(a[1], b[1])
#     w = min(a[0]+a[2], b[0]+b[2]) - x
#     h = min(a[1]+a[3], b[1]+b[3]) - y
#     if w<0 or h<0: return () # or (0,0,0,0) ?
#     return (x, y, w, h)

def area(box1, box2):
    y1,x1,y2,x2=box1
    yj1,xj1,yj2,xj2=box2
    if line_intersection((x1,y1,x2,y2), (xj1,yj1,xj2,yj2)):
        X1 = max(x1,xj1)
        Y1 = max(y1, yj1)
        X2 = min(x2, xj2)
        Y2 = min(y2, yj2)
        area=(X2-X1)*(Y2-Y1)
        return area
    else:
        return 0
def combiner(bbox, i):
    k=0
    # new_bbox=[]
    # for i in range(len(bbox)):
    yi1, xi1, yi2, xi2 = bbox[i]
    # print(xi1, yi1, xi2, yi2)
    for j in range(i,len(bbox)):
        yj1,xj1,yj2,xj2 = bbox[j]
        if area(xi1, yi1, xi2, yi2, xj1,yj1,xj2,yj2):
            xi1 = min(xi1, xj1)
            yi1 = min(yi1, yj1)
            xi2 = max(xi2, xj2)
            yi2 = max(yi2, yj2)

            k=k+1
            bbox[i] = [xi1, yi1, xi2, yi2]
    return bbox, k

def return_to_original_format(boxes):
    for i in range(len(boxes)):
        box = boxes[i]
        box = [box[0], box[1], box[0] + box[2], box[1] + box[3]]
        boxes[i] = box
    return boxes
################################################################################
# def combine_boxes(boxes):
#     noIntersectLoop = False
#     noIntersectMain = False
#     posIndex = 0
#      # keep looping until we have completed a full pass over each rectangle
#      # and checked it does not overlap with any other rectangle
#     while noIntersectMain == False:
#          noIntersectMain = True
#          posIndex = 0
#
#          while posIndex < len(boxes):
#              noIntersectLoop = False
#              while noIntersectLoop == False and len(boxes) > 1:
#                  a = boxes[posIndex]
#                  a = [a[1],a[0],a[3]-a[1],a[2]-a[0]]
#                  listBoxes = np.delete(boxes, posIndex, 0)
#                  index = 0
#                  for b in listBoxes:
#                     b = [b[1],b[0],b[3]-b[1],b[2]-b[0]]
#                     #if there is an intersection, the boxes overlap
#                     if intersection(a, b):
#                         newBox = union(a,b)
#                         listBoxes[index] = newBox
#                         boxes = listBoxes
#                         noIntersectLoop = False
#                         noIntersectMain = False
#                         index = index + 1
#                         break
#                     noIntersectLoop = True
#                     index = index + 1
#              posIndex = posIndex + 1
#     boxes = return_to_original_format(boxes)
#     return boxes
################################################################################
def combine_boxes(bbox):
    grouped_bbox=[]
    for BIC in bbox:
        # BIC=list(BIC)
        temp_group=[BIC]
        for grp_box in temp_group:
            for box in bbox:
                # box=list(box)
                # print(type(box), type(bbox))
                if box not in temp_group:
                    if area(box, grp_box) > 0:
                        temp_group.append(box)
        grouped_bbox.append(temp_group)
        #Remove grouped boxes from bbox
        # print(grouped_bbox)
        for indi_group in grouped_bbox:
            for bic in indi_group:
                if bic in bbox:
                    del(bbox[bbox.index(bic)])

    return grouped_bbox

def box_min(box_list, index):
    min_value=box_list[0][index]
    for i in range(1, len(box_list)):
        if box_list[i][index] < min_value:
            min_value = box_list[i][index]
    return min_value

def box_max(box_list, index):
    max_value=box_list[0][index]
    for i in range(1, len(box_list)):
        if box_list[i][index] > max_value:
            max_value = box_list[i][index]
    return max_value

def new_bbox(grouped_bbox):
    for i in range(len(grouped_bbox)):
        indi_grp=grouped_bbox[i]
        temp_x = box_min(indi_grp, 0)
        temp_y = box_min(indi_grp, 1)
        temp_x1 = box_max(indi_grp, 2)
        temp_y1 = box_max(indi_grp, 3)
        grouped_bbox[i] = [temp_x, temp_y, temp_x1, temp_y1]
    return grouped_bbox

def numpy_to_list_converter(bbox):
    if type(bbox) != 'list':
        bbox=list(bbox)
    for i in range(len(bbox)):
        box=bbox[i]
        if type(box) != 'list':
            bbox[i]=list(bbox[i])
    return bbox

def detector(bbox):
    # i=0
    # k=1
    list_bbox = numpy_to_list_converter(bbox)
    grouped_bbox=combine_boxes(list_bbox)
    print(grouped_bbox)
    New_bbox = new_bbox(grouped_bbox)

    # while(k>0):
    #     i+=1
    #     for j in range(len(bbox)):
    #         bbox, k = combiner(bbox, j)
    #         print('{}/{}'.format(str(i),str(k)), end='\r')

    return(grouped_bbox, New_bbox)
