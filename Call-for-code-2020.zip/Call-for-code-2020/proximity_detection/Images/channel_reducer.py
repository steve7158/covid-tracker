import cv2
import os


data_dir='dataset/'
target_dir='2_channel_data/'
for im_file in os.listdir(data_dir):
    im = cv2.imread(os.path.join(data_dir, im_file))
    im = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    cv2.imwrite(os.path.join(target_dir, im_file), im)
print('done')
